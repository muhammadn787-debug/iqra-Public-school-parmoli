This folder contains the website files for Iqra Public School Parmoli.

Files:
- index.html
- style.css
- logo.png (replace with your real logo if you want)

To preview: open index.html in your browser.
To publish on GitHub Pages: create a repository named 'iqra-school' and upload these files to the root branch 'main'.
